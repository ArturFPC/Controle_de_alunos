import java.util.Scanner;
/**
 *
 * @author artur
 */

public class Main {
    public static final int Num_Max = 1000;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner ler = new Scanner(System.in);
        boolean run = true;
        int qtdGraduado = 0;
        int qtdCursando = 0;
        Cursando[] cursando = new Cursando[Num_Max];
        Graduado[] graduado = new Graduado[Num_Max];
        cursando[0] = new Cursando();
        cursando[qtdCursando].setNome("Fulano");
        cursando[qtdCursando].setMatricula(5);
        cursando[qtdCursando].setSexo("Masculino");
        cursando[qtdCursando].setEstadoCivil("Solteiro");
        cursando[qtdCursando].setAnoDeNascimento(2000);
        cursando[qtdCursando].setCurso("Veterinária");
        cursando[qtdCursando].setEstadoEscolar("Cursando graduação");
        cursando[qtdCursando].setCRAtual(79.8);
        cursando[qtdCursando].setPeriodo(4);
        qtdCursando = qtdCursando +1;
        cursando[qtdCursando] = new Cursando();
        cursando[qtdCursando].setNome("Ciclano");
        cursando[qtdCursando].setMatricula(4);
        cursando[qtdCursando].setSexo("Masculino");
        cursando[qtdCursando].setEstadoCivil("Casado");
        cursando[qtdCursando].setAnoDeNascimento(1997);
        cursando[qtdCursando].setCurso("Biologia");
        cursando[qtdCursando].setEstadoEscolar("Cursando graduação");
        cursando[qtdCursando].setCRAtual(76);
        cursando[qtdCursando].setPeriodo(7);
        qtdCursando = qtdCursando+1;
        cursando[qtdCursando] = new Cursando();
        cursando[qtdCursando].setNome("Beltrana");
        cursando[qtdCursando].setMatricula(3);
        cursando[qtdCursando].setSexo("Feminino");
        cursando[qtdCursando].setEstadoCivil("Solteira");
        cursando[qtdCursando].setAnoDeNascimento(2002);
        cursando[qtdCursando].setCurso("Engenharia Cívil");
        cursando[qtdCursando].setEstadoEscolar("Cursando graduação");
        cursando[qtdCursando].setCRAtual(84);
        cursando[qtdCursando].setPeriodo(3);
        graduado[qtdGraduado] = new Graduado();
        graduado[qtdGraduado].setNome("Joaninha");
        graduado[qtdGraduado].setMatricula(1);
        graduado[qtdGraduado].setSexo("Feminino");
        graduado[qtdGraduado].setEstadoCivil("Casada");
        graduado[qtdGraduado].setAnoDeNascimento(1994);
        graduado[qtdGraduado].setCurso("Engenharia de Alimentos");
        graduado[qtdGraduado].setEstadoEscolar("Graduada");
        graduado[qtdGraduado].setCRDoCurso(80);
        graduado[qtdGraduado].setAnoDeConclusao(2019);
        graduado[qtdGraduado].setNivelDeEscolaridade("pós-graduação");
        qtdGraduado = qtdGraduado+1;
        graduado[qtdGraduado] = new Graduado();
        graduado[qtdGraduado].setNome("Pedroca");
        graduado[qtdGraduado].setMatricula(2);
        graduado[qtdGraduado].setSexo("Masculino");
        graduado[qtdGraduado].setEstadoCivil("Casado");
        graduado[qtdGraduado].setAnoDeNascimento(1995);
        graduado[qtdGraduado].setCurso("Ciência da Computação");
        graduado[qtdGraduado].setEstadoEscolar("Graduado");
        graduado[qtdGraduado].setCRDoCurso(78);
        graduado[qtdGraduado].setAnoDeConclusao(2019);
        graduado[qtdGraduado].setNivelDeEscolaridade("pós-graduação");
        while (run == true){
            int desejo;
            System.out.println("Digite um numero dentre as opções a seguir: ");
            System.out.println("1 - Inserir ex-aluno");
            System.out.println("2 - Inserir alunos");
            System.out.println("3 - Pesquisar ex-aluno");
            System.out.println("4 - Pesquisar aluno");
            System.out.println("5 - Sair");
            desejo = ler.nextInt();
            if (desejo==1){
                graduado[qtdGraduado].InserirGraduado(graduado[qtdGraduado], qtdGraduado);
            }
            if (desejo==2){
                cursando[qtdCursando].InserirCursando(cursando[qtdCursando], qtdCursando);
            }
            if(desejo==3){
                graduado[qtdGraduado].ProcurarGraduado(graduado, qtdGraduado);
            }
            if(desejo==4){
                cursando[qtdCursando].ProcurarCursando(cursando, qtdCursando);
            }
            if(desejo==5){
                run=false;
            }
        }
        
       
        
    }
    
}
