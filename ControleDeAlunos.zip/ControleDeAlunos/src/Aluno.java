
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author artur
 */
public class Aluno {
    private String nome;
    private int anoDeNascimento;
    private String sexo;
    private int matricula;
    private String curso;
    private String estadoCivil;
    private String estadoEscolar; // para saber se o aluno é formado ou não
    public Scanner ler = new Scanner(System.in);
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getAnoDeNascimento() {
        return anoDeNascimento;
    }

    public void setAnoDeNascimento(int ano_de_Nascimento) {
        this.anoDeNascimento = ano_de_Nascimento;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getEstadoEscolar() {
        return estadoEscolar;
    }

    public void setEstadoEscolar(String estadoEscolar) {
        this.estadoEscolar = estadoEscolar;
    }
    public void InserirAluno(Aluno x){
        System.out.println("Informe o nome do aluno: ");
        x.setNome(ler.nextLine());
        System.out.println("Informe o ano de nascimento do aluno: ");
        x.setAnoDeNascimento(Integer.parseInt(ler.nextLine()));
        System.out.println("Informe o sexo do aluno: ");
        x.setSexo(ler.nextLine());
        System.out.println("Informe a matricula do aluno: ");
        x.setMatricula(Integer.parseInt(ler.nextLine()));
        System.out.println("Informe o curso do aluno: ");
        x.setCurso(ler.nextLine());
        System.out.println("Informe o estado civil do aluno: ");
        x.setEstadoCivil(ler.nextLine());
    }
    
}
