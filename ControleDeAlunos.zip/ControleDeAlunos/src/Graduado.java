/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author artur
 */
public class Graduado extends Aluno{
    private int anoDeConclusao;
    private String nivelDeEscolaridade;
    private double CRDoCurso;

    public int getAnoDeConclusao() {
        return anoDeConclusao;
    }

    public void setAnoDeConclusao(int anoDeConclusao) {
        this.anoDeConclusao = anoDeConclusao;
    }

    public String getNivelDeEscolaridade() {
        return nivelDeEscolaridade;
    }

    public void setNivelDeEscolaridade(String nivelDeEscolaridade) {
        this.nivelDeEscolaridade = nivelDeEscolaridade;
    }

    public double getCRDoCurso() {
        return CRDoCurso;
    }

    public void setCRDoCurso(double CRDoCurso) {
        this.CRDoCurso = CRDoCurso;
    }
    public void InserirGraduado(Graduado x, int qtdGraduado){
        qtdGraduado = qtdGraduado+1;
        InserirAluno(x);
        x.setEstadoEscolar("Graduado");
        System.out.println("Informe o ano em que este aluno se formou: ");
        x.setAnoDeConclusao(Integer.parseInt(ler.nextLine()));
        System.out.println("Informe o coeficiente de rendimento que este aluno teve no curso: ");
        x.setCRDoCurso(Double.parseDouble(ler.nextLine()));
        System.out.println("Informe o nivel de escolaridade do aluno: ");
        System.out.println("(Graduação, pós-graduação, mestrado ou doutorado)");
        x.setNivelDeEscolaridade(ler.nextLine());    
    }
    public void ProcurarGraduado(Graduado x[], int qtdGraduado){
       int m;
       System.out.println("Informe a matricula do ex-aluno:");
       m = ler.nextInt();
       for(int i =0; i<=qtdGraduado; i++){
           if (m == x[i].getMatricula()){
               System.out.println("Nome: "+ x[i].getNome());
               System.out.println("Matricula: "+ x[i].getMatricula());
               System.out.println("Sexo: "+ x[i].getSexo());
               System.out.println("Ano de nascimento: "+ x[i].getAnoDeNascimento());
               System.out.println("Curso: "+ x[i].getCurso());
               System.out.println("Estado Cívil: "+ x[i].getEstadoCivil());
               System.out.println("Situação: "+x[i].getEstadoEscolar());
               System.out.println("Nivel de escolaridade: "+x[i].getNivelDeEscolaridade());
               System.out.println("Ano de conclusão do curso: "+ x[i].getAnoDeConclusao());
               System.out.println("Coeficiente de rendimento do curso: "+ x[i].getCRDoCurso());
               break;
           }
       }
   }
    
}
