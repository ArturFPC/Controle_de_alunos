/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author artur
 */
public class Cursando extends Aluno {
   private int periodo;
   private double CRAtual;
    public int getPeriodo() {
        return periodo;
    }

    public void setPeriodo(int período) {
        this.periodo = período;
    }

    public double getCRAtual() {
        return CRAtual;
    }

    public void setCRAtual(double CRAtual) {
        this.CRAtual = CRAtual;
    }
   public void InserirCursando(Cursando x, int qtdCursando){
        qtdCursando = qtdCursando +1;
        InserirAluno(x);
        x.setEstadoEscolar("Cursando graduação");
        System.out.println("Informe o periodo em  que o aluno está: ");
        x.setPeriodo(Integer.parseInt(ler.nextLine()));
        System.out.println("Informe o coeficiente de rendimento atual do aluno: ");
        x.setCRAtual(Double.parseDouble(ler.nextLine()));
    }
   public void ProcurarCursando(Cursando x[], int qtdCursando){
       int m;
       System.out.println("Informe a matricula do aluno:");
       m = ler.nextInt();
       for(int i =0; i<=qtdCursando; i++){
           if (x[i].getMatricula()==m){
               System.out.println("Nome: "+ x[i].getNome());
               System.out.println("Matricula: "+ x[i].getMatricula());
               System.out.println("Sexo: "+ x[i].getSexo());
               System.out.println("Ano de nascimento: "+ x[i].getAnoDeNascimento());
               System.out.println("Curso: "+ x[i].getCurso());
               System.out.println("Estado Cívil: "+ x[i].getEstadoCivil());
               System.out.println("Situação: "+x[i].getEstadoEscolar());
               System.out.println("Coeficiênte de rendimento atual: "+x[i].getCRAtual());
               System.out.println("Período: "+ x[i].getPeriodo());
               break;
           }
       }
   }
    
}
